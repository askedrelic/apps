({
    baseUrl: "../",
    name: "components/almond/almond.js",
    out: "../builds/converse.website-no-otr.min.js",
    include: ['main'],
    mainConfigFile: '../main.js',
    paths: {
        "converse-dependencies":    "src/deps-website-no-otr"
    }
})
