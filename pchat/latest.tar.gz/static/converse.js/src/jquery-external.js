define('jquery', [], function () {
    return jQuery;
});
