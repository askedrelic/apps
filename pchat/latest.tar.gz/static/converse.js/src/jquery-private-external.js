define(['jquery'], function (jq) {
    return jq;
});
