/*global define */

define([
  './intern.local'
], function (intern) {
  intern.proxyUrl = 'http://192.168.88.1:9000/';

  return intern;
});
