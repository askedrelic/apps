/*global define */

define([
    'tests/candy/functional/basics'
], function () {});
